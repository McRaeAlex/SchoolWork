# LLFS

This is my implementation of the LLFS filesystem. Run make to build all the tests.

## Building

in the root of the project run make